from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User,auth
# Create your views here.
#@login_required


def login(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect("/")
        else:
            return render(request,'login.html')
    else:
        return render(request,'login.html')

def register(request):

    if request.method=="POST":
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        username=request.POST['username']
        password1=request.POST['password1']
        password2=request.POST['password2']
        email=request.POST['email']
        if password1==password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'Username taken already')
                return render(request,"register.html")
            else:
        #save values in DB
                user=User.objects.create_user(username=username,email=email,password=password1,first_name=first_name,last_name=last_name)
                user.save()
                messages.info(request,'User created Successfully')
                return render(request,'login.html')
        else:
            messages.info(request,'password mismatch')
            return render(request,"register.html")
    else:
        return render(request,"register.html")
def index(request):
    auth.logout(request)
    return render(request,'index.html')