from django.apps import AppConfig


class DjangoauthenticationConfig(AppConfig):
    name = 'DjangoAuthentication'
