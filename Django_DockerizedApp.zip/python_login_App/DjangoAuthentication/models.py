from django.db import models

# Create your models here.
class Destination(models.Model):
    Name= models.CharField(max_length=200)
    Desc = models.TextField()
    Price = models.IntegerField()
    Offer = models.BooleanField(default=False)